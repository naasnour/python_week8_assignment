import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
try:
    df = pd.read_csv('owid-covid-data.csv')
    print("Dataset loaded successfully!")
except FileNotFoundError:
    print("CSV file not found. Please check the filename and path.")
    exit()

# Convert 'date' to datetime format
df['date'] = pd.to_datetime(df['date'])

# Filter for selected countries
countries = ['Senegal', 'India', 'United States']
df = df[df['location'].isin(countries)]

# Drop rows with missing critical data
df = df.dropna(subset=['total_cases', 'total_deaths', 'total_vaccinations'])

# Fill remaining NaNs with 0 for plotting
df[['new_cases', 'new_deaths', 'total_vaccinations']] = df[['new_cases', 'new_deaths', 'total_vaccinations']].fillna(0)

# TASK 1 - Basic Exploration
print("\nPreview of the data:")
print(df.head())

print("\nDataset Info:")
print(df.info())

print("\nMissing Values:")
print(df.isnull().sum())

# TASK 2 - Basic Data Analysis
print("\nBasic Statistics:")
print(df.describe())

# Grouping by country and getting average of total_cases
grouped = df.groupby('location')[['total_cases', 'total_deaths', 'total_vaccinations']].max()
print("\nGrouped Analysis (Max values):")
print(grouped)

# Add a new column: death rate
df['death_rate'] = df['total_deaths'] / df['total_cases']

# TASK 3 - Data Visualizations

# 1. Line Chart: Total Cases Over Time
plt.figure(figsize=(10, 6))
for country in countries:
    country_df = df[df['location'] == country]
    plt.plot(country_df['date'], country_df['total_cases'], label=country)
plt.title('Total COVID-19 Cases Over Time')
plt.xlabel('Date')
plt.ylabel('Total Cases')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# 2. Bar Chart: Max Total Cases Per Country
plt.figure(figsize=(8, 5))
sns.barplot(x=grouped.index, y=grouped['total_cases'])
plt.title('Total Cases Comparison')
plt.ylabel('Total Cases')
plt.tight_layout()
plt.show()

# 3. Histogram: Distribution of New Cases
plt.figure(figsize=(8, 5))
df[df['location'] == 'Senegal']['new_cases'].plot(kind='hist', bins=30, color='skyblue')
plt.title('New Cases Distribution - Senegal')
plt.xlabel('New Cases')
plt.tight_layout()
plt.show()

# 4. Scatter Plot: Total Cases vs Total Deaths
plt.figure(figsize=(8, 6))
sns.scatterplot(data=df, x='total_cases', y='total_deaths', hue='location')
plt.title('Cases vs Deaths')
plt.tight_layout()
plt.show()

# Additional: Vaccination Line Chart
plt.figure(figsize=(10, 6))
for country in countries:
    country_df = df[df['location'] == country]
    plt.plot(country_df['date'], country_df['total_vaccinations'], label=country)
plt.title('Vaccination Progress Over Time')
plt.xlabel('Date')
plt.ylabel('Total Vaccinations')
plt.legend()
plt.tight_layout()
plt.show()

# Final Insights
print("\n--- Final Observations ---")
print("1. United States has the highest case and vaccination numbers.")
print("2. Senegal shows fewer cases but with a consistent vaccination trend.")
print("3. Death rates vary by country – visible in the scatter plot.")
